Page({
  data: {
    imgUrls: [
      'https://i.loli.net/2017/12/28/5a44e7bab16a8.jpg',
      'https://i.loli.net/2017/12/28/5a44e80323ed4.png',
      'https://i.loli.net/2017/12/28/5a44e8312f6f6.png'
    ],
    list: [],
    indicatorDots: false,
    autoplay: false,
    interval: 2900,
    duration: 3000,
  },
  //轮播点击事件
  carouselClick:function(){
    // wx.navigateTo({
    //   url: 'list/list',
    // });

    var username = '991'
    var password = '991'
    var that = this
    wx.request({
      url: 'http://127.0.0.1:8000/list/',
      // header: { 'Content-Type': 'application/x-www-form-urlencoded' },
      // data: {
      //   username: username,
      //   password: password
      // },
      method: 'GET', // OPTIONS, GET, HEAD, POST, PUT, DELETE, TRACE, CONNECT
      // header: {}, // 设置请求的 header
      success: function (res) {

        console.log(res.data[0].fields.password)

        // success
      },
      fail: function () {
        // fail
      },
      complete: function () {
        // complete
      }
    })

  },

})
