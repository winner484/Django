from __future__ import unicode_literals
from django.shortcuts import render_to_response
from django.shortcuts import render
from app_user import models
from django.template import RequestContext
from django.core import serializers
from django.http import HttpResponse
from django.views.decorators.csrf import csrf_exempt
import json
# Create your views here.


# 增
@csrf_exempt
def insert(request):
    if request.method == "POST":
        username = request.POST.get('username')
        password = request.POST.get("password")
        print(username)
        print(password)
        models.message.objects.create(username=username, password=password)
        # models.message.save()
    # 给普通H5返回一个html模板
    # return render_to_response('insert.html',context_instance=RequestContext(request))
    # return render_to_response('insert.html',)
        # 给微信返回数据
        return HttpResponse("ok")

# 删
@csrf_exempt
def delete(request):
    if request.method == "POST":
        username = request.POST.get("username")
        # password = request.POST.get("password")
        models.message.objects.filter(username=username).delete()

        return HttpResponse("deletedone")

# 改
@csrf_exempt
def up(request):
    if request.method == 'POST':
        username = request.POST.get("username")
        password = request.POST.get("password")
        models.message.objects.filter(username=username).update(password=password)

        return HttpResponse("done")

# 查
def list(request):
    people_list = models.message.objects.all()
    json_data = serializers.serialize("json",people_list)
    print(json_data)
    # 这种返回是直接返回[{},{},{},{}...]，没有名字，调用的话，直接res.data[i].fields....
    return HttpResponse(json_data)

# 其他方法获取个数
    #
    # models.Tb1.objects.filter(name='seven').count()
    # 大于，小于
    #
    # models.Tb1.objects.filter(id__gt=1)              # 获取id大于1的值
    # models.Tb1.objects.filter(id__lt=10)             # 获取id小于10的值
    # models.Tb1.objects.filter(id__lt=10, id__gt=1)   # 获取id大于1 且 小于10的值
    # in
    #
    # models.Tb1.objects.filter(id__in=[11, 22, 33])   # 获取id等于11、22、33的数据
    # models.Tb1.objects.exclude(id__in=[11, 22, 33])  # not in
    # contains
    #
    # models.Tb1.objects.filter(name__contains="ven")
    # models.Tb1.objects.filter(name__icontains="ven") # icontains大小写不敏感
    # models.Tb1.objects.exclude(name__icontains="ven")
    # range
    #
    # models.Tb1.objects.filter(id__range=[1, 2])   # 范围bettwen and
    # 其他类似
    #
    # startswith，istartswith, endswith, iendswith,
    # order by
    #
    # models.Tb1.objects.filter(name='seven').order_by('id')    # asc
    # models.Tb1.objects.filter(name='seven').order_by('-id')   # desc
    # limit 、offset
    #
    # models.Tb1.objects.all()[10:20]
    # group by
    from django.db.models import Count, Min, Max, Sum
    # models.Tb1.objects.filter(c1=1).values('id').annotate(c=Count('num'))
    # SELECT "app01_tb1"."id", COUNT("app01_tb1"."num") AS "c" FROM "app01_tb1" WHERE "app01_tb1"."c1" = 1 GROUP BY "app01_tb1"."id"
